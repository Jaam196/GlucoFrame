# Guía de referencia: GlucoDataHandler (MIT)

Origen: https://github.com/pachi81/GlucoDataHandler (copyright 2023 Michael Pach, licencia MIT, ver LICENSE).
Instantánea de octubre de 2026. Cliente de LibreLinkUp en protocolo v4.x (versión por defecto 4.17.0). No incluye nada de la v5.

Úsalo SOLO como guía de comportamiento. No copies su arquitectura (depende de su propio sistema de preferencias, notificadores y servicio).
Si reutilizas lógica concreta, mantén el aviso de copyright MIT en un fichero NOTICE.md.

Ficheros:
- LibreLinkSourceTask.kt: login, redirección de región, cabeceras, estado 4 (tou/pp), versión mínima (403/920), conexiones, gráfico, parseo de lecturas.
- MultiPatientSourceTask.kt: selección de paciente cuando hay varias conexiones.
- DataSourceTask.kt: intervalos, reintentos, tratamiento de errores HTTP (429 a 5 min).
- NightscoutSourceTask.kt: endpoints y autenticación de Nightscout.
- HttpRequest.kt: tiempos de red (10 s conectar, 20 s leer).
- Utils.kt: SHA-256 y SHA-1 en hexadecimal.
- SOURCES.md: guía de alta de la cuenta de seguidor.
