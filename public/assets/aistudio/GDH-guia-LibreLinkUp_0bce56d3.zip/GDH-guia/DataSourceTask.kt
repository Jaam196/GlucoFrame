package de.michelinside.glucodatahandler.common.tasks

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import de.michelinside.glucodatahandler.common.utils.Log
import de.michelinside.glucodatahandler.common.AppSource
import de.michelinside.glucodatahandler.common.Constants
import de.michelinside.glucodatahandler.common.GlucoDataService
import de.michelinside.glucodatahandler.common.R
import de.michelinside.glucodatahandler.common.ReceiveData
import de.michelinside.glucodatahandler.common.SourceState
import de.michelinside.glucodatahandler.common.SourceStateData
import de.michelinside.glucodatahandler.common.database.dbAccess
import de.michelinside.glucodatahandler.common.notifier.DataSource
import de.michelinside.glucodatahandler.common.notifier.InternalNotifier
import de.michelinside.glucodatahandler.common.notifier.NotifySource
import de.michelinside.glucodatahandler.common.utils.HttpRequest
import de.michelinside.glucodatahandler.common.utils.Utils
import java.math.RoundingMode
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import androidx.core.content.edit

abstract class DataSourceTask(protected val enabledKey: String, protected val source: DataSource) : BackgroundTask() {
    protected var enabled = false
    private var prefInterval = 1
    protected open var minInterval = 1
    private var delaySec = 10L
    private var httpRequest = HttpRequest()
    protected var retry = false
    protected var firstGetValue = false
    private var isFirstRequest = true  // first request after startup
    private var lastExecution = 0L

    protected val interval: Int get() {
        return max(minInterval, prefInterval)
    }

    companion object {
        private val LOG_ID = "GDH.Task.Source.DataSourceTask"

        val preferencesToSend = mutableSetOf(
            Constants.SHARED_PREF_SOURCE_DELAY,
            Constants.SHARED_PREF_SOURCE_INTERVAL,
            Constants.SHARED_PREF_LIBRE_USER,
            Constants.SHARED_PREF_LIBRE_PASSWORD,
            Constants.SHARED_PREF_LIBRE_RECONNECT,
            Constants.SHARED_PREF_LIBRE_AUTO_ACCEPT_TOU,
            Constants.SHARED_PREF_LIBRE_PATIENT_ID,
            Constants.SHARED_PREF_LIBRE_SERVER,
            Constants.SHARED_PREF_NIGHTSCOUT_URL,
            Constants.SHARED_PREF_NIGHTSCOUT_SECRET,
            Constants.SHARED_PREF_NIGHTSCOUT_TOKEN,
            Constants.SHARED_PREF_NIGHTSCOUT_IOB_COB,
            Constants.SHARED_PREF_DEXCOM_SHARE_USER,
            Constants.SHARED_PREF_DEXCOM_SHARE_PASSWORD,
            Constants.SHARED_PREF_DEXCOM_SHARE_SERVER,
            Constants.SHARED_PREF_DEXCOM_SHARE_RECONNECT,
            Constants.SHARED_PREF_MEDTRUM_USER,
            Constants.SHARED_PREF_MEDTRUM_PASSWORD,
            Constants.SHARED_PREF_MEDTRUM_RECONNECT,
            Constants.SHARED_PREF_MEDTRUM_PATIENT_ID,
            Constants.SHARED_PREF_MEDTRUM_SERVER
        )
        fun updateSettings(context: Context, bundle: Bundle) {
            val sharedPref = context.getSharedPreferences(Constants.SHARED_PREF_TAG, Context.MODE_PRIVATE)
            sharedPref.edit {
                putInt(
                    Constants.SHARED_PREF_SOURCE_DELAY,
                    bundle.getInt(Constants.SHARED_PREF_SOURCE_DELAY, -1)
                )
                if (bundle.containsKey(Constants.SHARED_PREF_SOURCE_INTERVAL_DEPRECATED) && !bundle.containsKey(
                        Constants.SHARED_PREF_SOURCE_INTERVAL
                    )
                ) {
                    putInt(
                        Constants.SHARED_PREF_SOURCE_INTERVAL,
                        bundle.getString(Constants.SHARED_PREF_SOURCE_INTERVAL_DEPRECATED, "1")
                            .toInt()
                    )
                } else {
                    putInt(
                        Constants.SHARED_PREF_SOURCE_INTERVAL,
                        bundle.getInt(Constants.SHARED_PREF_SOURCE_INTERVAL, 1)
                    )
                }

                putString(
                    Constants.SHARED_PREF_LIBRE_USER,
                    bundle.getString(Constants.SHARED_PREF_LIBRE_USER, "")
                )
                putString(
                    Constants.SHARED_PREF_LIBRE_PASSWORD,
                    bundle.getString(Constants.SHARED_PREF_LIBRE_PASSWORD, "")
                )
                putBoolean(
                    Constants.SHARED_PREF_LIBRE_RECONNECT,
                    bundle.getBoolean(Constants.SHARED_PREF_LIBRE_RECONNECT, false)
                )
                putBoolean(
                    Constants.SHARED_PREF_LIBRE_AUTO_ACCEPT_TOU,
                    bundle.getBoolean(Constants.SHARED_PREF_LIBRE_AUTO_ACCEPT_TOU, true)
                )
                putString(
                    Constants.SHARED_PREF_LIBRE_SERVER,
                    bundle.getString(Constants.SHARED_PREF_LIBRE_SERVER, "io")
                )
                putString(
                    Constants.SHARED_PREF_LIBRE_PATIENT_ID,
                    bundle.getString(Constants.SHARED_PREF_LIBRE_PATIENT_ID, "")
                )

                putString(
                    Constants.SHARED_PREF_NIGHTSCOUT_URL,
                    bundle.getString(Constants.SHARED_PREF_NIGHTSCOUT_URL, "")
                )
                putString(
                    Constants.SHARED_PREF_NIGHTSCOUT_SECRET,
                    bundle.getString(Constants.SHARED_PREF_NIGHTSCOUT_SECRET, "")
                )
                putString(
                    Constants.SHARED_PREF_NIGHTSCOUT_TOKEN,
                    bundle.getString(Constants.SHARED_PREF_NIGHTSCOUT_TOKEN, "")
                )
                putBoolean(
                    Constants.SHARED_PREF_NIGHTSCOUT_IOB_COB,
                    bundle.getBoolean(Constants.SHARED_PREF_NIGHTSCOUT_IOB_COB, true)
                )

                putString(
                    Constants.SHARED_PREF_DEXCOM_SHARE_USER,
                    bundle.getString(Constants.SHARED_PREF_DEXCOM_SHARE_USER, "")
                )
                putString(
                    Constants.SHARED_PREF_DEXCOM_SHARE_PASSWORD,
                    bundle.getString(Constants.SHARED_PREF_DEXCOM_SHARE_PASSWORD, "")
                )
                putString(
                    Constants.SHARED_PREF_DEXCOM_SHARE_SERVER,
                    bundle.getString(Constants.SHARED_PREF_DEXCOM_SHARE_SERVER, "eu")
                )
                putBoolean(
                    Constants.SHARED_PREF_DEXCOM_SHARE_RECONNECT,
                    bundle.getBoolean(Constants.SHARED_PREF_DEXCOM_SHARE_RECONNECT, false)
                )

                putString(
                    Constants.SHARED_PREF_MEDTRUM_USER,
                    bundle.getString(Constants.SHARED_PREF_MEDTRUM_USER, "")
                )
                putString(
                    Constants.SHARED_PREF_MEDTRUM_PASSWORD,
                    bundle.getString(Constants.SHARED_PREF_MEDTRUM_PASSWORD, "")
                )
                putBoolean(
                    Constants.SHARED_PREF_MEDTRUM_RECONNECT,
                    bundle.getBoolean(Constants.SHARED_PREF_MEDTRUM_RECONNECT, false)
                )
                putString(
                    Constants.SHARED_PREF_MEDTRUM_PATIENT_ID,
                    bundle.getString(Constants.SHARED_PREF_MEDTRUM_PATIENT_ID, "")
                )
                putString(
                    Constants.SHARED_PREF_MEDTRUM_SERVER,
                    bundle.getString(Constants.SHARED_PREF_MEDTRUM_SERVER, "eu")
                )

            }
            InternalNotifier.notify(context, NotifySource.SOURCE_SETTINGS, null)
        }
        fun getSettingsBundle(sharedPref: SharedPreferences): Bundle {
            val bundle = Bundle()
            bundle.putInt(Constants.SHARED_PREF_SOURCE_DELAY, sharedPref.getInt(Constants.SHARED_PREF_SOURCE_DELAY, -1))
            bundle.putString(Constants.SHARED_PREF_SOURCE_INTERVAL_DEPRECATED, sharedPref.getInt(Constants.SHARED_PREF_SOURCE_INTERVAL, 1).toString())
            bundle.putInt(Constants.SHARED_PREF_SOURCE_INTERVAL, sharedPref.getInt(Constants.SHARED_PREF_SOURCE_INTERVAL, 1))

            bundle.putString(Constants.SHARED_PREF_LIBRE_USER, sharedPref.getString(Constants.SHARED_PREF_LIBRE_USER, ""))
            bundle.putString(Constants.SHARED_PREF_LIBRE_PASSWORD, sharedPref.getString(Constants.SHARED_PREF_LIBRE_PASSWORD, ""))
            bundle.putBoolean(Constants.SHARED_PREF_LIBRE_RECONNECT, sharedPref.getBoolean(Constants.SHARED_PREF_LIBRE_RECONNECT, false))
            bundle.putBoolean(Constants.SHARED_PREF_LIBRE_AUTO_ACCEPT_TOU, sharedPref.getBoolean(Constants.SHARED_PREF_LIBRE_AUTO_ACCEPT_TOU, true))
            bundle.putString(Constants.SHARED_PREF_LIBRE_SERVER, sharedPref.getString(Constants.SHARED_PREF_LIBRE_SERVER, "io"))
            bundle.putString(Constants.SHARED_PREF_LIBRE_PATIENT_ID, sharedPref.getString(Constants.SHARED_PREF_LIBRE_PATIENT_ID, ""))

            bundle.putString(Constants.SHARED_PREF_NIGHTSCOUT_URL, sharedPref.getString(Constants.SHARED_PREF_NIGHTSCOUT_URL, ""))
            bundle.putString(Constants.SHARED_PREF_NIGHTSCOUT_SECRET, sharedPref.getString(Constants.SHARED_PREF_NIGHTSCOUT_SECRET, ""))
            bundle.putString(Constants.SHARED_PREF_NIGHTSCOUT_TOKEN, sharedPref.getString(Constants.SHARED_PREF_NIGHTSCOUT_TOKEN, ""))
            bundle.putBoolean(Constants.SHARED_PREF_NIGHTSCOUT_IOB_COB, sharedPref.getBoolean(Constants.SHARED_PREF_NIGHTSCOUT_IOB_COB, true))

            bundle.putString(Constants.SHARED_PREF_DEXCOM_SHARE_USER, sharedPref.getString(Constants.SHARED_PREF_DEXCOM_SHARE_USER, ""))
            bundle.putString(Constants.SHARED_PREF_DEXCOM_SHARE_PASSWORD, sharedPref.getString(Constants.SHARED_PREF_DEXCOM_SHARE_PASSWORD, ""))
            bundle.putString(Constants.SHARED_PREF_DEXCOM_SHARE_SERVER, sharedPref.getString(Constants.SHARED_PREF_DEXCOM_SHARE_SERVER, "eu"))
            bundle.putBoolean(Constants.SHARED_PREF_DEXCOM_SHARE_RECONNECT, sharedPref.getBoolean(Constants.SHARED_PREF_DEXCOM_SHARE_RECONNECT, false))

            bundle.putString(Constants.SHARED_PREF_MEDTRUM_USER, sharedPref.getString(Constants.SHARED_PREF_MEDTRUM_USER, ""))
            bundle.putString(Constants.SHARED_PREF_MEDTRUM_PASSWORD, sharedPref.getString(Constants.SHARED_PREF_MEDTRUM_PASSWORD, ""))
            bundle.putBoolean(Constants.SHARED_PREF_MEDTRUM_RECONNECT, sharedPref.getBoolean(Constants.SHARED_PREF_MEDTRUM_RECONNECT, false))
            bundle.putString(Constants.SHARED_PREF_MEDTRUM_PATIENT_ID, sharedPref.getString(Constants.SHARED_PREF_MEDTRUM_PATIENT_ID, ""))
            bundle.putString(Constants.SHARED_PREF_MEDTRUM_SERVER, sharedPref.getString(Constants.SHARED_PREF_MEDTRUM_SERVER, "eu"))

            return bundle
        }

        fun getFirstNeedGraphValueTime(interval: Int, isFirstRequest: Boolean = false, forceReturnMinTime: Boolean = false): Long {
            val firstLastPair = dbAccess.getFirstLastTimestamp()
            val minTime = if(GlucoDataService.appSource == AppSource.AUTO_APP)
                System.currentTimeMillis() - Constants.DB_MAX_DATA_GDA_TIME_MS     // only for delta calculation
            else
                System.currentTimeMillis() - Constants.DB_MAX_DATA_WEAR_TIME_MS    // 24h for init the first time
            Log.d(LOG_ID, "get first need value for first: ${Utils.getElapsedTimeMinute(firstLastPair.first)}, last: ${
                Utils.getElapsedTimeMinute(firstLastPair.second)}, min: ${Utils.getElapsedTimeMinute(minTime)}")
            if(firstLastPair.first == 0L || (isFirstRequest && firstLastPair.first > minTime)) {
                Log.i(LOG_ID, "First value is ${Utils.getElapsedTimeMinute(firstLastPair.first)} minutes old - try get older data on first request")
                return minTime
            }
            if(firstLastPair.second > 0L && (Utils.getElapsedTimeMinute(firstLastPair.second) > interval || forceReturnMinTime)) {
                Log.i(LOG_ID, "Last value is ${Utils.getElapsedTimeMinute(firstLastPair.second)} minutes old - try get newer data")
                return maxOf(firstLastPair.second + 30000, minTime)
            }
            return 0L
        }
    }

    override fun getDataSource(): DataSource {
        return source
    }

    var lastState = SourceState.NONE
    var lastErrorCode: Int = -1

    fun setLastError(error: String, code: Int = -1, message: String = "")  {
        setState(SourceState.ERROR, error, code, message)
    }

    fun setState(state: SourceState, error: String = "", code: Int = -1, message: String = "") {
        when (state) {
            SourceState.NONE -> {
                Log.v(LOG_ID, "Set state for source $source: $state - $error ($code) - message: $message")
            }
            SourceState.CONNECTED -> {
                Log.i(LOG_ID, "Set connected for source $source")
                isFirstRequest = false
            }
            SourceState.NO_NEW_VALUE -> {
                Log.i(LOG_ID, "No new value for source $source - $error ($code) - message: $message")
                isFirstRequest = false
            }
            else -> {
                Log.w(LOG_ID, "Set state for source $source: $state - $error ($code) - message: $message")
            }
        }
        lastErrorCode = code
        lastState = state

        SourceStateData.setState(source, state, getErrorMessage(state, error, code), getErrorInfo(code, message))
    }

    private fun getErrorMessage(state: SourceState, error: String, code: Int): String {
        if (state == SourceState.ERROR && code > 0) {
            return "$code: ${getErrorMessage(code, error)}"
        }
        return error
    }

    private fun isShortInterval(): Boolean {
        return when(lastState) {
            SourceState.NO_CONNECTION,
            SourceState.NO_NEW_VALUE -> true
            SourceState.ERROR -> lastErrorCode >= 500
            else -> false
        }
    }

    private fun isLongInterval(): Boolean {
        return when(lastState) {
            SourceState.ERROR -> lastErrorCode == 429
            else -> false
        }
    }

    open fun authenticate(): Boolean = true

    open fun reset() {}

    abstract fun getValue(): Boolean

    private fun executeRequest(firstCall: Boolean = true) {
        try {
            Log.d(LOG_ID, "executeRequest called: firstCall: $firstCall")
            firstGetValue = false // for setting login errors
            if (authenticate()) {
                firstGetValue = firstCall
                retry = false
                if(!getValue() && firstCall && retry)
                    executeRequest(false) // retry if internal client error or invalid session id
            }
        } catch(ex: SocketTimeoutException) {
            Log.e(LOG_ID, "Timeout occurs: ${ex.message}")
            reset()
            if(firstCall) {
                executeRequest(false)
            } else {
                setLastError(GlucoDataService.context!!.resources.getString(R.string.timeout))
            }
        }
    }

    open fun needsInternet(): Boolean = true

    override fun execute(context: Context, force: Boolean) {
        if (force || canExecute()) {
            if (needsInternet() && !HttpRequest.isConnected(context)) {
                Log.w(LOG_ID, "No internet connection")
                setState(SourceState.NO_CONNECTION)
                return
            }
            Log.d(LOG_ID, "Execute request for $source - lastExecution: ${Utils.getUiTimeStamp(lastExecution)} - force: $force")
            try {
                lastExecution = System.currentTimeMillis()
                executeRequest()
            } catch (ex: InterruptedException) {
                throw ex // re throw interruption
            } catch(ex: SocketTimeoutException) {
                Log.w(LOG_ID, "Timeout for $source: " + ex)
                setLastError(context.resources.getString(R.string.timeout))
            } catch (ex: UnknownHostException) {
                Log.w(LOG_ID, "Internet connection issue for $source: " + ex)
                setState(SourceState.NO_CONNECTION)
            } catch (ex: Exception) {
                Log.e(LOG_ID, "Exception during execution for $source: " + ex)
                setLastError(ex.message.toString())
            }
            httpRequest.stop()
        }
    }

    open fun getNoNewValueInfo(time: Long): String = ""

    protected fun handleIobResult(extras: Bundle) {
        if(Log.isLoggable(LOG_ID, android.util.Log.DEBUG))
            Log.d(LOG_ID, "handleIobResult for $source: ${Utils.dumpBundle(extras)}")
        if(!ReceiveData.hasNewIobCob(extras)) {
            setState(SourceState.CONNECTED)
            return
        }
        Handler(Looper.getMainLooper()).post {
            try {
                ReceiveData.handleIobCob(GlucoDataService.context!!, source, extras)
                setState(SourceState.CONNECTED)
            } catch (exc: Exception) {
                Log.e(LOG_ID, "Handle IOB exception: " + exc.message.toString() )
                SourceStateData.setError(source, exc.message.toString())
            }
        }
    }

    protected fun handleResult(extras: Bundle) {
        if(Log.isLoggable(LOG_ID, android.util.Log.DEBUG))
            Log.d(LOG_ID, "handleResult for $source: ${Utils.dumpBundle(extras)}")
        if(!ReceiveData.hasNewValue(extras)) {
            if(extras.containsKey(ReceiveData.TIME)) {
                val valueTime = extras.getLong(ReceiveData.TIME)
                if(Utils.getElapsedTimeMinute(valueTime) >= minInterval) {
                    setState(
                        SourceState.NO_NEW_VALUE,
                        GlucoDataService.context!!.resources.getString(R.string.last_value_on_server, Utils.getUiTimeStamp(extras.getLong(ReceiveData.TIME))),
                        -1,
                        getNoNewValueInfo(valueTime)
                    )
                }
            } else {
                setState(SourceState.NO_NEW_VALUE)
            }
            return
        }

        /*val intent = Intent(GlucoDataService.context!!, InternalActionReceiver::class.java)
        intent.action = Intents.GLUCODATA_ACTION
        intent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
        intent.setPackage(GlucoDataService.context!!.packageName)
        extras.putInt(Constants.EXTRA_SOURCE_INDEX, source.ordinal)
        intent.putExtras(extras)
        setState(SourceState.CONNECTED)
        GlucoDataService.context!!.sendBroadcast(intent)
        */
        val done = AtomicBoolean(false)
        val active = AtomicBoolean(false)
        val task = Runnable {
            try {
                active.set(true)
                Log.d(LOG_ID, "handleResult for $source in main thread")
                ReceiveData.handleIntent(GlucoDataService.context!!, source, extras)
                if(ReceiveData.getElapsedTimeMinute(RoundingMode.UP) > interval) {
                    if(ReceiveData.getElapsedTimeMinute(RoundingMode.UP) < interval * 2) {
                        setState(
                            SourceState.NO_NEW_VALUE,
                            GlucoDataService.context!!.resources.getString(R.string.source_delay_too_short)
                        )
                    } else {
                        setState(
                            SourceState.NO_NEW_VALUE,
                            GlucoDataService.context!!.resources.getString(R.string.last_value_on_server, Utils.getUiTimeStamp(extras.getLong(ReceiveData.TIME))),
                            -1,
                            getNoNewValueInfo(extras.getLong(ReceiveData.TIME))
                        )
                    }
                } else {
                    setState(SourceState.CONNECTED)
                }
            } catch (ex: Exception) {
                Log.e(LOG_ID, "Exception during task run: " + ex)
                setLastError(ex.message.toString())
            }
            done.set(true)
        }
        val handler = Handler(Looper.getMainLooper())
        handler.post(task)
        var count = 0
        while (!done.get() && count < 30000) {
            Thread.sleep(10)
            count += 10
            if(count.mod(5000) == 0) {
                Log.w(LOG_ID, "Handle result for $source not finished after $count ms! Active: ${active.get()} Mainlopper: Queue-Idle: ${Looper.getMainLooper().queue.isIdle}")
            }
        }
        if(!done.get()) {
            Log.e(LOG_ID, "Handler for $source not finished after $count ms! Active: ${active.get()} - Stop it!")
            handler.removeCallbacksAndMessages(null)
            setLastError(GlucoDataService.context!!.resources.getString(R.string.internal_error), -1, GlucoDataService.context!!.resources.getString(R.string.provide_logs))
        }
        Log.d(LOG_ID, "handleResult for " + source + " done!")
    }

    protected fun getErrorMessage(code: Int, message: String?): String {
        when(code) {
            429 -> return GlucoDataService.context!!.resources.getString(R.string.http_error_429)
            else -> return message ?: "Error"
        }
    }

    protected fun getErrorInfo(code: Int, message: String? = null): String {
        when(code) {
            429 -> return GlucoDataService.context!!.resources.getString(R.string.http_error_429_info)
            else -> return message ?: ""
        }
    }

    open fun checkErrorResponse(code: Int, message: String?, errorResponse: String? = null) {
        Log.e(LOG_ID, "checkErrorResponse: $code - $message - $errorResponse - (firstGetValue: $firstGetValue)")
        if (code >= 400) {  // reset for client and server errors -> better re-connect
            reset() // reset token for client error -> trigger reconnect
            if(firstGetValue) {
                retry = true
                return
            }
        }
        var errorMessage = getErrorMessage(code, message)
        if(errorResponse != null && !errorResponse.startsWith("<")) {  // not for HTML responses!
            errorMessage += "\n" + errorResponse
        }
        setLastError(errorMessage, code, getErrorInfo(code))
    }

    open fun getTrustAllCertificates(): Boolean = false


    override fun interrupt() {
        super.interrupt()
        if(httpRequest.connected) {
            Log.w(LOG_ID, "Disconnect current URL connection on interrupt!")
            httpRequest.stop()
        }
    }

    private fun checkResponse(responseCode: Int): String? {
        if (responseCode != HttpURLConnection.HTTP_OK) {
            checkErrorResponse(responseCode, httpRequest.responseMessage, httpRequest.responseError)
            return null
        }
        return httpRequest.response
    }

    protected fun getHeaderField(name: String): String? {
        return httpRequest.getHeaderField(name)
    }

    protected fun httpGet(url: String, header: MutableMap<String, String>): String? {
        return checkResponse(httpRequest.get(url, header, getTrustAllCertificates()))
    }

    protected fun httpPost(url: String, header: MutableMap<String, String>, postData: String?): String? {
        return checkResponse(httpRequest.post(url, postData, header, getTrustAllCertificates()))
    }

    override fun getIntervalMinute(): Long {
        if (interval > 1 && isShortInterval()) {
            Log.d(LOG_ID, "Use short interval of 1 minute.")
            return 1L   // retry after a minute
        }
        if (interval == 1 && isLongInterval()) {
            return 5L  // increase interval for case of "429: Too many requests"
        }
        return interval.toLong()
    }

    override fun getDelayMs(): Long = delaySec * 1000L

    override fun active(elapsetTimeMinute: Long): Boolean {
        return enabled
    }

    private fun canExecute(): Boolean {
        if(enabled && (lastExecution == 0L || Utils.getElapsedTimeMinute(lastExecution, RoundingMode.HALF_UP) >= 1))
            return true
        else if(enabled) {
            Log.d(LOG_ID, "Skip execution - lastExecution: ${Utils.getUiTimeStamp(lastExecution)}")
        }
        return false
    }


    override fun forceExecution(): Boolean {
        if(enabled && (lastExecution == 0L || Utils.getElapsedTimeMinute(lastExecution) >= getIntervalMinute())) {
            Log.i(LOG_ID, "Force execution after " + Utils.getElapsedTimeMinute(lastExecution) + " min")
            return true
        }
        return false
    }

    protected open fun disable() {}
    protected open fun enable() {}

    private fun setEnabled(newEnabled: Boolean): Boolean {
        Log.d(LOG_ID, "Set enabled=$newEnabled (old: $enabled) for $source")
        if(newEnabled != enabled) {
            enabled = newEnabled
            Log.i(LOG_ID, "Set enabled=$enabled for $source")
            if(enabled)
                enable()
            else
                disable()
            if (source == SourceStateData.lastSource) {
                setState(SourceState.NONE)
                if(SourceStateData.lastState != SourceState.CONNECTED)
                    lastExecution = 0L  // reset execution to try again immediately on error
            }
            return true
        }
        return false
    }

    override fun checkPreferenceChanged(sharedPreferences: SharedPreferences, key: String?, context: Context): Boolean {
        Log.d(LOG_ID, "checkPreferenceChanged for $key")
        if(key == null) {
            setEnabled(sharedPreferences.getBoolean(enabledKey, false))
            prefInterval = sharedPreferences.getInt(Constants.SHARED_PREF_SOURCE_INTERVAL, 1)
            delaySec = sharedPreferences.getInt(Constants.SHARED_PREF_SOURCE_DELAY, 30).toLong()
            if(GlucoDataService.appSource == AppSource.WEAR_APP)
                delaySec += 5L  // add 5 seconds delay to receive by phone if connected
            return true
        } else {
            var result = false
            when(key) {
                enabledKey -> {
                    result = setEnabled(sharedPreferences.getBoolean(enabledKey, false))
                }
                Constants.SHARED_PREF_SOURCE_INTERVAL -> {
                    if (prefInterval != (sharedPreferences.getInt(Constants.SHARED_PREF_SOURCE_INTERVAL, 1))) {
                        prefInterval = sharedPreferences.getInt(Constants.SHARED_PREF_SOURCE_INTERVAL, 1)
                        result = true
                    }
                }
                Constants.SHARED_PREF_SOURCE_DELAY -> {
                    if (delaySec != sharedPreferences.getInt(Constants.SHARED_PREF_SOURCE_DELAY, 30).toLong()) {
                        delaySec = sharedPreferences.getInt(Constants.SHARED_PREF_SOURCE_DELAY, 30).toLong()
                        if(GlucoDataService.appSource == AppSource.WEAR_APP)
                            delaySec += 5L // add 5 seconds delay to receive by phone if connected
                        result = true  // retrigger alarm after delay has changed
                    }
                }
            }
            return result
        }
    }

    protected fun getFirstNeedGraphValueTime(): Long {
        return getFirstNeedGraphValueTime(interval, isFirstRequest)
    }
}
