package de.michelinside.glucodatahandler.common.utils

import android.accessibilityservice.AccessibilityServiceInfo
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.PackageManager.NameNotFoundException
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Parcel
import android.provider.Settings
import android.text.format.DateUtils
import android.util.TypedValue
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import de.michelinside.glucodatahandler.common.Constants
import de.michelinside.glucodatahandler.common.GlucoDataService
import de.michelinside.glucodatahandler.common.R
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.io.OutputStream
import java.math.RoundingMode
import java.security.MessageDigest
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.time.Duration
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Calendar
import java.util.Date
import java.util.concurrent.TimeUnit
import kotlin.math.max
import androidx.core.content.edit


object Utils {
    private val LOG_ID = "GDH.Utils.Utils"
    fun round(value: Float, scale: Int, roundingMode: RoundingMode = RoundingMode.HALF_UP): Float {
        if (value.isNaN())
            return value
        return value.toBigDecimal().setScale( scale, roundingMode).toFloat()
    }

    // check for valid values
    fun getCobValue(value: Float): Float {
        if (value < 0)
            return Float.NaN
        return value
    }

    fun rangeValue(value: Float, min: Float, max: Float): Float {
        if (value > max)
            return max
        if (value < min)
            return min
        return value
    }

    fun getVersion(versionString: String?): String {
        if(!versionString.isNullOrEmpty()) {
            val regex = "[0-9]+(\\.[0-9]+)*".toRegex()
            // If there is matching string, then find method returns non-null MatchResult
            val match = regex.find(versionString)
            if (match != null) {
                return match.value
            }
        }
        return ""
    }

    // return -1 if current < new, 1 if current > new
    fun compareVersion(current: String?, new: String?): Int {
        val curVersion = getVersion(current)
        val newVersion = getVersion(new)
        if (curVersion.isEmpty() && newVersion.isEmpty())
            return 0
        if (newVersion.isEmpty()) return 1
        if (curVersion.isEmpty()) return -1
        val curParts = curVersion.split(".")
        val newParts = newVersion.split(".")
        val length = max(curParts.size, newParts.size)
        for (i in 0 until length) {
            val curPart = if (i < curParts.size) curParts[i].toInt() else 0
            val newPart = if (i < newParts.size) newParts[i].toInt() else 0
            if (curPart < newPart) return -1
            if (curPart > newPart) return 1
        }
        return 0
    }

    fun parseFloatString(floatValue: String?): Float {
        if(!floatValue.isNullOrEmpty()) {
            try {
                return floatValue.replace(',', '.').toFloat()
            } catch (exc: NumberFormatException) {
                Log.e(LOG_ID, "Error parsing float value $floatValue exception: ${exc.message}")
            }
        }
        return Float.NaN
    }

    fun dpToPx(dp: Float, context: Context): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp,
            context.resources.displayMetrics
        ).toInt()
    }

    fun spToPx(sp: Float, context: Context): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP,
            sp,
            context.resources.displayMetrics
        ).toInt()
    }

    fun bytesToBundle(bytes: ByteArray?, isJson: Boolean = true): Bundle? {
        try {
            if(bytes==null)
                return null
            if(isJson)
                return JsonUtils.jsonBytesToBundle(bytes)
            val parcel = Parcel.obtain()
            parcel.unmarshall(bytes, 0, bytes.size)
            parcel.setDataPosition(0)
            val bundle = parcel.readBundle(GlucoDataService::class.java.getClassLoader())
            parcel.recycle()
            dumpBundle(bundle)  // workaround for problems with API 36
            return bundle
        } catch (exc: Exception) {
            Log.e(LOG_ID, "bytesToBundle exception: " + exc.toString())
            return null
        }
    }

    fun bundleToBytes(bundle: Bundle?, useJson: Boolean = true): ByteArray? {
        if (bundle==null)
            return null
        try {
            if(useJson)
                return JsonUtils.bundleToJsonBytes(bundle)
            val parcel = Parcel.obtain()
            parcel.writeBundle(bundle)
            val bytes = parcel.marshall()
            parcel.recycle()
            return bytes
        } catch (exc: Exception) {
            Log.e(LOG_ID, "bundleToBytes exception: " + exc.toString())
            return null
        }
    }

    @Suppress("DEPRECATION")
    fun dumpBundle(bundle: Bundle?, prefix: String = ""): String {
        try {
            if (bundle == null) {
                return "NULL"
            }
            var string = "{\r\n"
            for (key in bundle.keySet()) {
                string += if(bundle[key] is Bundle) {
                    prefix + "  " + key + " => Bundle: " + dumpBundle(bundle[key] as Bundle, prefix + "  ") + "\r\n"
                } else {
                    prefix + "  " + key + " => " + (if (bundle[key] != null) (bundle[key]!!.javaClass.simpleName + ": " + bundle[key].toString()) else "NULL") + "\r\n"
                }
                if(string.length >= 2000)
                    return string.take(2000)
            }
            string += prefix + "}"
            return string
        } catch (exc: Exception) {
            Log.e(LOG_ID, "dumpBundle exception: " + exc.toString() + "\n" + exc.stackTraceToString() )
        }
        return bundle.toString()
    }

    @SuppressLint("ObsoleteSdkInt")
    fun checkPermission(context: Context, permission: String, minSdk: Int = Build.VERSION_CODES.O): Boolean {
        if (Build.VERSION.SDK_INT >= minSdk) {
            if (context.checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                Log.w(LOG_ID, "Permission " + permission + " not granted!")
                return false
            }
        }
        Log.d(LOG_ID, "Permission " + permission + " granted!")
        return true
    }

    fun getBackgroundColor(transparancyFactor: Int) : Int {
        if( transparancyFactor <= 0 )
            return 0
        val transparency = 255 * minOf(10, transparancyFactor) / 10
        return transparency shl (4*6)
    }

    fun isHighContrastTextEnabled(context: Context): Boolean {
        return Settings.Secure.getInt(context.contentResolver, "high_text_contrast_enabled", 0) == 1
        /*if (context != null) {
            val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            var m: Method? = null
            try {
                m = am.javaClass.getMethod("isHighTextContrastEnabled", null)
            } catch (e: NoSuchMethodException) {
                Log.i(LOG_ID, "isHighTextContrastEnabled not found in AccessibilityManager")
            }
            val result: Any
            if (m != null) {
                try {
                    result = m.invoke(am, null)!!
                    if (result is Boolean) {
                        return result
                    }
                } catch (e: Exception) {
                    Log.i(LOG_ID, "isHighTextContrastEnabled invoked with an exception" + entry.message)
                }
            }
        }
        return false*/
    }

    fun byteToHex(num: Byte): String {
        val hexDigits = CharArray(2)
        hexDigits[0] = Character.forDigit(num.toInt() shr 4 and 0xF, 16)
        hexDigits[1] = Character.forDigit(num.toInt() and 0xF, 16)
        return String(hexDigits)
    }
    fun toHexString(bytes: ByteArray): String {
        val hexStringBuffer = StringBuffer()
        for (element in bytes) {
            hexStringBuffer.append(byteToHex(element))
        }
        return hexStringBuffer.toString()
    }

    fun encryptSHA1(value: String?): String {
        if (value.isNullOrEmpty() || value.trim().isEmpty())
            return ""
        try {
            val message: ByteArray = value.trim().toByteArray(Charsets.UTF_8)
            val md = MessageDigest.getInstance("SHA-1")
            val digest: ByteArray = md.digest(message)
            return toHexString(digest)
        } catch (ex: Exception) {
            Log.e(LOG_ID, "Exception while encrypt SHA-1: " + ex)
        }
        return ""
    }


    fun encryptSHA256(value: String): String {
        if (value.trim().isEmpty())
            return ""
        try {
            val message: ByteArray = value.trim().toByteArray(Charsets.UTF_8)
            val md = MessageDigest.getInstance("SHA-256")
            val digest: ByteArray = md.digest(message)
            return toHexString(digest)
        } catch (ex: Exception) {
            Log.e(LOG_ID, "Exception while encrypt SHA-256: " + ex)
        }
        return ""
    }

    fun getDeviceInformations(): String {
        var s = ""
        try {
            if(GlucoDataService.context!=null) {
                val pInfo: PackageInfo = GlucoDataService.context!!.packageManager.getPackageInfo(
                    GlucoDataService.context!!.packageName, PackageManager.GET_META_DATA
                )
                s += "APP Package Name: ${GlucoDataService.context!!.packageName}\n"
                s += "APP Version Name: ${pInfo.versionName}\n"
                s += "APP Version Code: ${pInfo.versionCode}\n"
            }
        } catch (e: NameNotFoundException) {
        }
        s += "Runtime: " + if(GlucoDataService.runtimeDays>0L) "${GlucoDataService.runtimeDays} days\n" else "${GlucoDataService.runtimeMin} minutes\n"
        s += "OS Version: ${System.getProperty("os.version")} (${Build.VERSION.INCREMENTAL})\n"
        s += "OS API Level: ${Build.VERSION.SDK_INT}\n"
        s += "Android: ${Build.VERSION.RELEASE}\n"
        s += "Device: ${Build.DEVICE}\n"
        s += "Model (and Product): ${Build.MODEL} (${Build.PRODUCT})\n"
        s += "Manufacturer: ${Build.MANUFACTURER}\n"
        s += "Other TAGS: ${Build.TAGS}\n"
        try {
            if(GlucoDataService.context != null) {
                val pi: PackageInfo =
                    GlucoDataService.context!!.packageManager.getPackageInfo(GlucoDataService.context!!.packageName, PackageManager.GET_PERMISSIONS)
                if(pi.requestedPermissions != null && pi.requestedPermissions?.isNotEmpty() == true) {
                    s += "---------------------PERMISSIONS:------------------------------\n"
                    for (i in pi.requestedPermissions!!.indices) {
                        s += "${pi.requestedPermissions!![i]}:"
                        if ((pi.requestedPermissionsFlags!![i] and 1) != 0)
                            s+= " REQUIRED"
                        if ((pi.requestedPermissionsFlags!![i] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0)
                            s+= " GRANTED"
                        s+= " (${pi.requestedPermissionsFlags!![i]})\n"
                    }
                }
                if(GlucoDataService.sharedPref != null && GlucoDataService.sharedPref!!.contains(Constants.SHARED_PREF_UNCAUGHT_EXCEPTION_MESSAGE)) {
                    s += "---------------------------------------------------------------\n\n"
                    s += "---------------------UNCAUGHT EXCEPTION:-----------------------\n"
                    val excMsg = GlucoDataService.sharedPref!!.getString(Constants.SHARED_PREF_UNCAUGHT_EXCEPTION_MESSAGE, "") ?: ""
                    val time = GlucoDataService.sharedPref!!.getLong(Constants.SHARED_PREF_UNCAUGHT_EXCEPTION_TIME, 0)
                    s+= getUiTimeStamp(time) + "\n"
                    s+= excMsg + "\n"
                }
            }
        } catch (e: java.lang.Exception) {
        }
        s += "---------------------------------------------------------------\n\n"
        return s
    }

    fun saveLogs(context: Context, uri: Uri) {
        try {
            Thread {
                try {
                    context.contentResolver.openFileDescriptor(uri, "w")?.use {
                        FileOutputStream(it.fileDescriptor).use { os ->
                            saveLogs(os)
                        }
                    }
                } catch (exc: Exception) {
                    Log.e(LOG_ID, "Saving logs to stream exception: " + exc.message.toString() )
                }
            }.start()
        } catch (exc: Exception) {
            Log.e(LOG_ID, "Saving logs to file exception: " + exc.message.toString() )
        }
    }

    fun saveLogs(outputStream: OutputStream) {
        try {
            outputStream.write(getDeviceInformations().toByteArray())
            outputStream.flush()
            val cmd: String
            if(Log.dbLoggingEnabled) {
                outputStream.write(Log.getLogs().toByteArray())
                outputStream.flush()
                cmd = "logcat *:W -t 4000"
            } else {
                cmd = "logcat -t 4000"
            }
            Log.i(LOG_ID, "Getting logcat with command: $cmd")
            val process = Runtime.getRuntime().exec(cmd)
            val thread = Thread {
                try {
                    try {
                        Log.v(LOG_ID, "read")
                        val buffer = ByteArray(4 * 1024) // or other buffer size
                        var read: Int
                        while (process.inputStream.read(buffer).also { rb -> read = rb } != -1) {
                            Log.v(LOG_ID, "write")
                            outputStream.write(buffer, 0, read)
                        }
                    } catch (exc: Exception) {
                        Log.e(LOG_ID, "Writing logs exception: " + exc.message.toString() )
                        outputStream.write("Exception while writing logs:".toByteArray())
                        outputStream.write(exc.message.toString().toByteArray())
                        outputStream.write(exc.stackTraceToString().toByteArray())
                    }
                    Log.v(LOG_ID, "flush")
                    outputStream.flush()
                    outputStream.close()
                } catch (exc: Exception) {
                    Log.e(LOG_ID, "Exception while closing stream: " + exc.message.toString() )
                }
            }
            thread.start()
            Log.v(LOG_ID, "Waiting for saving logs")
            process.waitFor(10, TimeUnit.SECONDS)
            Log.v(LOG_ID, "Process alive: ${process.isAlive}")
            var count = 0
            while (process.isAlive && count < 10) {
                Log.w(LOG_ID, "Killing process")
                process.destroy()
                Thread.sleep(1000)
                count++
            }
            Log.v(LOG_ID, "Process exit: ${process.exitValue()}")
            val text = if (process.exitValue() == 0) {
                GlucoDataService.context!!.resources.getText(R.string.logcat_save_succeeded)
            } else {
                GlucoDataService.context!!.resources.getText(R.string.logcat_save_failed)
            }
            Handler(GlucoDataService.context!!.mainLooper).post {
                Toast.makeText(GlucoDataService.context!!, text, Toast.LENGTH_SHORT).show()
            }
        } catch (exc: Exception) {
            Log.e(LOG_ID, "Saving logs exception: " + exc.message.toString() )
            outputStream.write("Exception while reading logcat:".toByteArray())
            outputStream.write(exc.message.toString().toByteArray())
            outputStream.write(exc.stackTraceToString().toByteArray())
            outputStream.flush()
            outputStream.close()
        }
    }

    fun saveSettings(context: Context, uri: Uri) {
        try {
            Thread {
                context.contentResolver.openFileDescriptor(uri, "w")?.use {
                    FileOutputStream(it.fileDescriptor).use { os ->
                        saveSettings(os, context)
                    }
                }
            }.start()
        } catch (exc: Exception) {
            Log.e(LOG_ID, "Saving logs to file exception: " + exc.message.toString() )
        }
    }

    private fun saveSettings(outputStream: OutputStream, context: Context) {
        var success = false
        try {
            val sharedPref = context.getSharedPreferences(Constants.SHARED_PREF_TAG, Context.MODE_PRIVATE)
            val oos = ObjectOutputStream(outputStream)
            oos.writeObject(sharedPref.getAll())
            oos.close()
            success = true
            Log.i(LOG_ID, "Settings saved")
        } catch (exc: Exception) {
            Log.e(LOG_ID, "Saving settings exception: " + exc.message.toString() )
        }
        val text = if (success) {
            GlucoDataService.context!!.resources.getText(R.string.settings_save_succeeded)
        } else {
            GlucoDataService.context!!.resources.getText(R.string.settings_save_failed)
        }
        Handler(GlucoDataService.context!!.mainLooper).post {
            Toast.makeText(GlucoDataService.context!!, text, Toast.LENGTH_SHORT).show()
        }
    }

    fun readSettings(context: Context, uri: Uri) {
        try {
            Thread {
                context.contentResolver.openFileDescriptor(uri, "r")?.use {
                    FileInputStream(it.fileDescriptor).use { iss ->
                        readSettings(iss, context)
                    }
                }
            }.start()
        } catch (exc: Exception) {
            Log.e(LOG_ID, "Saving logs to file exception: " + exc.message.toString() )
        }
    }

    private fun readSettings(inputStream: InputStream, context: Context) {
        var success = false
        try {
            val sharedPref = context.getSharedPreferences(Constants.SHARED_PREF_TAG, Context.MODE_PRIVATE)
            val ois = ObjectInputStream(inputStream)
            val map = ois.readObject() as? Map<*, *> ?: emptyMap<String, Any>()
            val enableMap = mutableMapOf<String, Any?>()
            val editor = sharedPref.edit()

            map.entries.forEach { entry ->
                val key = entry.key.toString()
                if (!key.endsWith("_enabled")) {
                    applySetting(editor, key, entry.value)
                } else {
                    Log.v(LOG_ID, "Add to enable map: $key")
                    enableMap[key] = entry.value
                }
            }
            editor.apply()
            Log.d(LOG_ID, "Applying enable settings: ${enableMap.keys}")
            enableMap.forEach { entry ->
                val key = entry.key
                applySetting(editor, key, entry.value)
            }
            editor.apply()
            success = true
            Log.i(LOG_ID, "Settings sucessfully read")
        } catch (exc: Exception) {
            Log.e(LOG_ID, "Reading settings exception: " + exc.message.toString() )
        }
        val text = if (success) {
            GlucoDataService.context!!.resources.getText(R.string.settings_read_succeeded)
        } else {
            GlucoDataService.context!!.resources.getText(R.string.settings_read_failed)
        }
        Handler(GlucoDataService.context!!.mainLooper).post {
            Toast.makeText(GlucoDataService.context!!, text, Toast.LENGTH_SHORT).show()
        }
    }

    private fun applySetting(editor: SharedPreferences.Editor, key: String, value: Any?) {
        //Log.v(LOG_ID, "Apply setting $key: '$value'")
        editor.putString(key, value.toString())
        when (value) {
            is Boolean -> editor.putBoolean(key, value)
            is String -> editor.putString(key, value)
            is Int -> editor.putInt(key, value)
            is Float -> editor.putFloat(key, value)
            is Long -> editor.putLong(key, value)
            is Set<*> -> editor.putStringSet(key, value as? Set<String> ?: emptySet())
            else -> throw IllegalArgumentException(
                "Type " + (value?.javaClass?.name ?: "unknown") + " is unknown"
            )
        }
    }

    fun timeInDayFilter(currentDateTime: LocalDateTime, startTime: LocalTime, weekDayFilter: MutableSet<String>?): Boolean {
        try {
            if(weekDayFilter == null || weekDayFilter.size == 7)
                return true
            if (weekDayFilter.isEmpty())
                return false
            val currentTime = currentDateTime.toLocalTime()
            val timeDiff = if(currentTime.isBefore(startTime)) startTime.until(currentTime, ChronoUnit.MINUTES) + 1440 else startTime.until(currentTime, ChronoUnit.MINUTES)
            val startDateTime = currentDateTime.minusMinutes(timeDiff)
            if(weekDayFilter.contains(startDateTime.dayOfWeek.value.toString()))
                return true
        } catch (exc: Exception) {
            Log.e(LOG_ID, "timeInDayFilter exception: " + exc.message.toString() )
        }
        return false
    }

    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm")
    private val simpleTimeFormatter = SimpleDateFormat("HH:mm")


    fun isValidTime(time: String?): Boolean {
        if (time.isNullOrEmpty())
            return false
        try {
            LocalTime.parse(time, timeFormatter)
            return true
        } catch(_: Exception) {
        }
        return false
    }

    @SuppressLint("SimpleDateFormat")
    fun timeBetweenTimes(currentTime: LocalDateTime, startTime: String, endTime: String, weekDayFilter: MutableSet<String>? = null): Boolean {
        try {
            if (!isValidTime(startTime) || !isValidTime(endTime))
                return false
            val timeCur = currentTime.toLocalTime()
            val timeStart = LocalTime.parse(startTime, timeFormatter)
            val timeEnd = LocalTime.parse(endTime, timeFormatter)

            if (timeCur == null || timeStart == null || timeEnd == null)
                return false

            if (timeCur == timeStart || timeCur == timeEnd)
                return timeInDayFilter(currentTime, timeStart, weekDayFilter)

            if (timeStart.isAfter(timeEnd)) {  // night shift
                if (timeCur.isAfter(timeStart) || timeCur.isBefore(timeEnd))
                    return timeInDayFilter(currentTime, timeStart, weekDayFilter)
            } else {
                if (timeCur.isAfter(timeStart) && timeCur.isBefore(timeEnd))
                    return timeInDayFilter(currentTime, timeStart, weekDayFilter)
            }
        } catch (exc: Exception) {
            Log.e(LOG_ID, "timeBetweenTimes exception: " + exc.message.toString() )
        }
        return false
    }

    /**
     * Parses a time string in "HH:mm" format and returns the next future timestamp (in epoch milliseconds)
     * that matches the given time and the optional weekDayFilter.
     *
     * @param time The time string in "HH:mm" format.
     * @param weekDayFilter A set of strings representing the days of the week (1=Monday, 7=Sunday).
     *                      If null or size 7, it's considered to apply to all days.
     *                      If empty, no day matches.
     * @return The next future timestamp in epoch milliseconds, or 0 if parsing fails or no match is found within a reasonable future.
     */
    fun parseTimeAndGetNextTimestamp(time: String, weekDayFilter: MutableSet<String>? = null): Long {
        try {
            Log.d(LOG_ID, "parseTimeAndGetNextTimestamp for time $time and filter $weekDayFilter")
            if (!isValidTime(time)) {
                Log.w(LOG_ID, "Invalid time format: $time")
                return 0
            }
            if(weekDayFilter != null && weekDayFilter.isEmpty())
                return 0

            val targetLocalTime = LocalTime.parse(time, timeFormatter)

            var nextDateTime = LocalDateTime.now()
            val maxSearchDays = 7 // Begrenzen Sie die Suche auf 7 Tage, um Endlosschleifen zu vermeiden

            for (i in 0 until maxSearchDays) {
                // Prüfe, ob die aktuelle Zeit passt, falls wir gerade die Zielzeit erreichen/überschritten haben
                // (nur relevant, wenn wir heute noch nicht über die Zeit hinaus sind)
                if (i > 0) { // Wenn wir uns in der Zukunft befinden, setzen wir die Zeit auf den nächsten Tag
                    nextDateTime = nextDateTime.plusDays(1)
                }

                val currentTargetDateTime = nextDateTime.with(targetLocalTime)

                Log.v(LOG_ID, "Checking currentTargetDateTime: $currentTargetDateTime - localTime: ${LocalDateTime.now()}")
                // Prüfe, ob die gefundene Zeit in der Zukunft liegt (oder exakt jetzt ist, falls das auch zählt)
                // Wenn die Zeit bereits in der Vergangenheit liegt für den heutigen Tag, müssen wir den nächsten Tag nehmen
                if (currentTargetDateTime.isBefore(LocalDateTime.now()) && i == 0) {
                    continue // Versuche es mit dem nächsten Tag
                }

                // Prüfe den Wochentagsfilter
                if (weekDayFilter == null || weekDayFilter.size == 7) {
                    // Wenn kein Filter oder alle Tage drin, dann passt es immer
                    Log.v(LOG_ID, "Use currentTargetDateTime: $currentTargetDateTime")
                    return currentTargetDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                } else {
                    // Wochentag ist 1 (Montag) bis 7 (Sonntag)
                    val currentDayOfWeekValue = currentTargetDateTime.dayOfWeek.value.toString()
                    if (weekDayFilter.contains(currentDayOfWeekValue)) {
                        Log.v(LOG_ID, "Use currentTargetDateTime for day $currentDayOfWeekValue: $currentTargetDateTime")
                        return currentTargetDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                    }
                }
            }

            Log.w(LOG_ID, "Could not find a matching timestamp within the next $maxSearchDays days for time $time and filter $weekDayFilter")
            return 0 // Keine passende Zeit innerhalb der nächsten Tage gefunden

        } catch (exc: Exception) {
            Log.e(LOG_ID, "parseTimeAndGetNextTimestamp exception for time '$time' and filter $weekDayFilter: " + exc.message.toString() )
            return 0
        }
    }


    fun getElapsedTimeMinute(time: Long, roundingMode: RoundingMode = RoundingMode.DOWN): Long {
        return round((System.currentTimeMillis()-time).toFloat()/60000, 0, roundingMode).toLong()
    }

    fun getTimeDiffMinute(time1: Long, time2: Long, roundingMode: RoundingMode = RoundingMode.DOWN): Long {
        return round((time1-time2).toFloat()/60000, 0, roundingMode).toLong()
    }

    fun getUiTimeStamp(time: Long): String {
        if(DateUtils.isToday(time))
            return getTimeStamp(time)
        return DateFormat.getDateTimeInstance().format(Date(time))
    }

    fun getTimeStamp(time: Long): String {
        return DateFormat.getTimeInstance(DateFormat.DEFAULT).format(Date(time))
    }

    // returns the current day start time
    fun getDayStartTime(time: Long = System.currentTimeMillis()): Long {
        val calendar = Calendar.getInstance()
        calendar.time = Date(time)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        //calendar.set(2025, 1, 1, 0, 0, 0)
        return calendar.time.time
    }

    fun Context.isScreenReaderOn():Boolean{
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        if (am.isEnabled) {
            val serviceInfoList =
                am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_SPOKEN)
            if (serviceInfoList.isNotEmpty())
                return true
        }
        return false
    }

    fun canScheduleExactAlarms(context: Context): Boolean {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            return alarmManager.canScheduleExactAlarms()
        }
        return true
    }

    fun formatDuration(duration: Duration): String {
        return formatDurationFromSeconds(duration.toMillis()/1000)
    }

    fun formatDurationFromSeconds(totalSeconds: Long): String {
        if (totalSeconds < 0) return "Invalid duration"

        val days = TimeUnit.SECONDS.toDays(totalSeconds)
        val remainingSecondsAfterDays = totalSeconds - TimeUnit.DAYS.toSeconds(days)

        val hours = TimeUnit.SECONDS.toHours(remainingSecondsAfterDays)
        val remainingSecondsAfterHours = remainingSecondsAfterDays - TimeUnit.HOURS.toSeconds(hours)

        val minutes = TimeUnit.SECONDS.toMinutes(remainingSecondsAfterHours)
        val seconds = remainingSecondsAfterHours - TimeUnit.MINUTES.toSeconds(minutes)


        val parts = mutableListOf<String>()
        if (days > 0) parts.add("$days day${if (days > 1) "s" else ""}")
        if (hours > 0) parts.add("$hours hour${if (hours > 1) "s" else ""}")
        if (minutes > 0) parts.add("$minutes minute${if (minutes > 1) "s" else ""}")
        if (seconds > 0) parts.add("$seconds second${if (seconds > 1) "s" else ""}")


        return if (parts.isEmpty()) {
            "0 minutes"
        } else {
            parts.joinToString(", ")
        }
    }

    fun parseRegexGroupValues(valueToParse: String, regex: Regex): List<String>? {
        return regex.find(valueToParse.replace(",", ".").trim().lowercase())?.groupValues
    }

    fun replaceSensitiveData(body: String?, sensitivData: MutableSet<String>): String {
        try {
            if(body == null)
                return "<null>"
            var result = body.take(1100)
            sensitivData.forEach {
                val groups = Regex("\"$it\":\"(.*?)\"").find(result)?.groupValues
                if(!groups.isNullOrEmpty() && groups.size > 1 && groups[1].isNotEmpty()) {
                    val replaceValue = groups[0].replace(groups[1], "---")
                    result = result.replace(groups[0], replaceValue)
                }
            }
            return result.take(1000)
        } catch (exc: Exception) {
            Log.e(LOG_ID, "replaceSensitiveData exception: " + exc.toString() )
            return "<err>"
        }
    }

}